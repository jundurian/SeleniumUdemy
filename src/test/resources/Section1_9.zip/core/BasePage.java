package core;

public class BasePage {

    protected DSL dsl;

    public BasePage(){
        dsl = new DSL();
    }
}
