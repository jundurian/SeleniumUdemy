package core;

public class Propriedades {

    public static boolean FECHAR_BROWSER = false;

    public static Browsers browsers = Browsers.FIREFOX;

    public enum Browsers{
        CHROME,
        FIREFOX
    }
}
